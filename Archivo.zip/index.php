<!DOCTYPE html>
<html lang="en">
<?php
$title = 'Inicio';
$inicio = 'active';
include('includes/head.php');
?>

<body>
    <div class="page-wrapper">
        <?php
        include('includes/header.php');
        include('modules/index.php');
        include('includes/footer.php');
        include('includes/scripts.php');
        ?>
    </div>
</body>

</html>